# Companion 当前交付与待办

## 当前交付与工作点

[嵌入式当前待办](RECORDER_CORE_BACKLOG.md)是本侧工作入口；[原工程编号](PRODUCT_BACKLOG_HISTORY.md)只作历史与证据索引。

## 产品交付模块

沿原六个模块保留各自范围和用户验收状态。嵌软工作包不替代整个产品的交付模块。

| 模块 | 用户验收状态 |
|---|---|
| 录音卡到电脑：录音、保存、同步、转写和AI整理 | 未整体关闭 |
| 手机端：统一前端与现有后端 | 未整体关闭 |
| 电脑资料管理：找得到、听得回、能导出 | 已关闭 |
| 交付与售前售后 | 未整体关闭 |
| 宠物与设备交互 | Owner暂停，录音卡工作完成后再回来 |
| 其他原有能力与后续事项 | 未整体关闭 |

## 电脑与手机侧当前记录

以下直接读取同事维护的当前批次；不从旧共享版本别名推断安装。

- **当前下一步：** After shared66687 OTA final receipt/release, verify actual installed version; install062 only if no newer candidate, else merge. Retest Word affected route, return original library, then only self-created actual-card pause/resume/stop/receive/playback/delete and original-audio save/share. Inherit completed OTA evidence without needless repeat.

各模块旧版本实施笔记保留在历史索引，不混入本页当前交付。

- 电脑资料管理：找得到、听得回、能导出用户验收：{'at': '2026-11-02T07:40:46+08:00', 'reply': '同意关闭', 'scope': '电脑资料管理软件常用流程；查找、回听、编辑、导出、备份恢复和重新打开由工程后台核验。'}

## 完整录音卡任务书与逐项验收

按Owner要求，将竞品能力、实际质量、双端体验与交付条件列入原任务。以下是同一份product_backlog.json的生成视图，沿原CP编号执行。

**工程完成与Owner验收分别记录。** 工程完成后列出可检查版本、证据与未覆盖条件；只有你明确对本项及该版本表示通过，才登记已验收。你可以稍后逐项验收，工程不必等待每个开发动作批准。

原Windows等模块已经验收的子范围继续保留；新扩大范围不自动继承全部通过。模型暂停、实物及账号依赖照原指示处理，遇到依赖保留未完成并继续独立工作。

| 项 | 功能与原任务 | 次序 | 工程状态 | 你的验收 |
|---|---|---|---|---|
| 1 | [离线录音、可靠保存和同步恢复](#acceptance-capture)<br>[CP27-01](PRODUCT_BACKLOG_HISTORY.md#cp27-01)、[CP27-11](PRODUCT_BACKLOG_HISTORY.md#cp27-11)、[CP27-18](PRODUCT_BACKLOG_HISTORY.md#cp27-18)、[CP16-03](PRODUCT_BACKLOG_HISTORY.md#cp16-03) | P0 | 工程待完成；含实物验收 | 待你验收 |
| 2 | [设备重点、回听及上下文参与整理](#acceptance-marks)<br>[CP27-17](PRODUCT_BACKLOG_HISTORY.md#cp27-17)、[CP20-01](PRODUCT_BACKLOG_HISTORY.md#cp20-01) | P0 | 工程待完成；模型验证暂停 | 待你验收 |
| 3 | [手机通话录音与模式切换](#acceptance-call)<br>[CP27-02](PRODUCT_BACKLOG_HISTORY.md#cp27-02)、[CP27-12](PRODUCT_BACKLOG_HISTORY.md#cp27-12) | P1 | 工程待完成；含实物验收 | 待你验收 |
| 4 | [线上会议直接采集](#acceptance-desktop_capture)<br>[CP27-03](PRODUCT_BACKLOG_HISTORY.md#cp27-03) | P1 | 工程待完成（已有部分成果） | 待你验收 |
| 5 | [音视频与文档/图片导入](#acceptance-import)<br>[CP27-03](PRODUCT_BACKLOG_HISTORY.md#cp27-03)、[CP27-05](PRODUCT_BACKLOG_HISTORY.md#cp27-05) | P1 | 工程待完成（已有部分成果） | 待你验收 |
| 6 | [文字备注、图片与时间点上下文](#acceptance-notes_images)<br>[CP27-05](PRODUCT_BACKLOG_HISTORY.md#cp27-05)、[CP20-05](PRODUCT_BACKLOG_HISTORY.md#cp20-05) | P1 | 工程待完成（已有部分成果） | 待你验收 |
| 7 | [实时转写草稿与会后最终结果](#acceptance-live)<br>[CP10-03](PRODUCT_BACKLOG_HISTORY.md#cp10-03)、[CP27-11](PRODUCT_BACKLOG_HISTORY.md#cp27-11) | P1 | 工程待完成；模型验证暂停 | 待你验收 |
| 8 | [准确转写、长会与资源占用](#acceptance-asr)<br>[CP11-01](PRODUCT_BACKLOG_HISTORY.md#cp11-01)、[CP11-07](PRODUCT_BACKLOG_HISTORY.md#cp11-07)、[CP20-07](PRODUCT_BACKLOG_HISTORY.md#cp20-07) | P0 | 工程待完成；模型验证暂停 | 待你验收 |
| 9 | [多人区分、姓名与角色确认](#acceptance-speakers)<br>[CP11-03](PRODUCT_BACKLOG_HISTORY.md#cp11-03)、[CP11-04](PRODUCT_BACKLOG_HISTORY.md#cp11-04) | P0 | 工程待完成；模型验证暂停 | 待你验收 |
| 10 | [噪声与重叠语音处理](#acceptance-overlap_noise)<br>[CP11-04](PRODUCT_BACKLOG_HISTORY.md#cp11-04)、[CP11-07](PRODUCT_BACKLOG_HISTORY.md#cp11-07)、[CP27-12](PRODUCT_BACKLOG_HISTORY.md#cp27-12) | P0 | 工程待完成；模型验证暂停 | 待你验收 |
| 11 | [个人词表、专名及数字纠正](#acceptance-vocab)<br>[CP20-04](PRODUCT_BACKLOG_HISTORY.md#cp20-04)、[CP11-07](PRODUCT_BACKLOG_HISTORY.md#cp11-07) | P1 | 工程待完成；模型验证暂停 | 待你验收 |
| 12 | [转写校对、易读稿与原文定位](#acceptance-editing)<br>[CP11-03](PRODUCT_BACKLOG_HISTORY.md#cp11-03)、[CP10-04](PRODUCT_BACKLOG_HISTORY.md#cp10-04)、[CP12-06](PRODUCT_BACKLOG_HISTORY.md#cp12-06) | P1 | 工程待完成（已有部分成果） | 待你验收 |
| 13 | [结构纪要、结论、行动与事实依据](#acceptance-minutes)<br>[CP12-01](PRODUCT_BACKLOG_HISTORY.md#cp12-01)、[CP12-02](PRODUCT_BACKLOG_HISTORY.md#cp12-02)、[CP12-08](PRODUCT_BACKLOG_HISTORY.md#cp12-08) | P0 | 工程待完成；模型验证暂停 | 待你验收 |
| 14 | [场景模板、自定义与多视角结果](#acceptance-templates)<br>[CP27-04](PRODUCT_BACKLOG_HISTORY.md#cp27-04)、[CP12-09](PRODUCT_BACKLOG_HISTORY.md#cp12-09) | P1 | 软件已交付；手机前台/AI效果待验 | 待你验收 |
| 15 | [单会/跨会问答和引用](#acceptance-qa)<br>[CP27-06](PRODUCT_BACKLOG_HISTORY.md#cp27-06)、[CP12-06](PRODUCT_BACKLOG_HISTORY.md#cp12-06) | P1 | 工程待完成；模型验证暂停 | 待你验收 |
| 16 | [多语言、双语与实时翻译](#acceptance-translation)<br>[CP27-07](PRODUCT_BACKLOG_HISTORY.md#cp27-07)、[CP12-09](PRODUCT_BACKLOG_HISTORY.md#cp12-09) | P1 | 工程待完成；模型验证暂停 | 待你验收 |
| 17 | [思维导图和可用导出](#acceptance-mindmap)<br>[CP27-09](PRODUCT_BACKLOG_HISTORY.md#cp27-09) | P1 | Windows052完整PNG与可编辑mm已交付；长图交互及安卓完整范围待完成 | 待你验收 |
| 18 | [行动事项、负责人/时间与后续材料](#acceptance-actions)<br>[CP12-07](PRODUCT_BACKLOG_HISTORY.md#cp12-07)、[CP12-05](PRODUCT_BACKLOG_HISTORY.md#cp12-05)、[CP27-06](PRODUCT_BACKLOG_HISTORY.md#cp27-06) | P1 | 工程待完成（已有部分成果） | 待你验收 |
| 19 | [日历关联、会议准备和提醒](#acceptance-calendar)<br>[CP12-05](PRODUCT_BACKLOG_HISTORY.md#cp12-05)、[CP27-10](PRODUCT_BACKLOG_HISTORY.md#cp27-10) | P1 | 工程待完成；有外部依赖 | 待你验收 |
| 20 | [全库检索与回找依据](#acceptance-search)<br>[CP14-07](PRODUCT_BACKLOG_HISTORY.md#cp14-07)、[CP27-06](PRODUCT_BACKLOG_HISTORY.md#cp27-06) | P1 | 工程待完成（已有部分成果） | 待你验收 |
| 21 | [文件夹、标签、批量管理](#acceptance-organization)<br>[CP27-08](PRODUCT_BACKLOG_HISTORY.md#cp27-08) | P1 | 工程待完成（已有部分成果） | 待你验收 |
| 22 | [倍速、定位、续听及静音跳过](#acceptance-playback)<br>[CP27-14](PRODUCT_BACKLOG_HISTORY.md#cp27-14)、[CP27-25](PRODUCT_BACKLOG_HISTORY.md#cp27-25) | P1 | 工程待完成（已有部分成果） | 待你验收 |
| 23 | [非破坏剪辑、切分和合并](#acceptance-trim_merge)<br>[CP27-16](PRODUCT_BACKLOG_HISTORY.md#cp27-16) | P1 | 工程待完成（已有部分成果） | 待你验收 |
| 24 | [保护、回收站与明确清除](#acceptance-trash)<br>[CP27-27](PRODUCT_BACKLOG_HISTORY.md#cp27-27)、[CP13-02](PRODUCT_BACKLOG_HISTORY.md#cp13-02) | P0 | Android069回收站候选已准备，真实手机与资料保留验收待完成 | 待你验收 |
| 25 | [按内容/格式导出、复制与分享](#acceptance-exports)<br>[CP27-09](PRODUCT_BACKLOG_HISTORY.md#cp27-09)、[CP12-04](PRODUCT_BACKLOG_HISTORY.md#cp12-04)、[CP14-08](PRODUCT_BACKLOG_HISTORY.md#cp14-08) | P0 | Windows068文件夹分享与状态修复已安装、后台核对；真实收件及安卓Word/录控等余项未齐 | 待你验收 |
| 26 | [完整备份、换机恢复与版本](#acceptance-backup)<br>[CP14-06](PRODUCT_BACKLOG_HISTORY.md#cp14-06)、[CP14-01](PRODUCT_BACKLOG_HISTORY.md#cp14-01) | P0 | 工程待完成；有外部依赖 | 待你验收 |
| 27 | [账号、跨端同步和客户端覆盖](#acceptance-cross_platform)<br>[CP27-10](PRODUCT_BACKLOG_HISTORY.md#cp27-10)、[CP16-06](PRODUCT_BACKLOG_HISTORY.md#cp16-06)、[CP16-09](PRODUCT_BACKLOG_HISTORY.md#cp16-09) | P1 | 工程待完成；有外部依赖 | 待你验收 |
| 28 | [自动同步整理与可复用工作流](#acceptance-automation)<br>[CP27-11](PRODUCT_BACKLOG_HISTORY.md#cp27-11)、[CP27-04](PRODUCT_BACKLOG_HISTORY.md#cp27-04)、[CP27-06](PRODUCT_BACKLOG_HISTORY.md#cp27-06) | P1 | 工程待完成；有外部依赖 | 待你验收 |
| 29 | [日历、笔记、CRM与API/MCP集成](#acceptance-integrations)<br>[CP27-10](PRODUCT_BACKLOG_HISTORY.md#cp27-10)、[CP25-05](PRODUCT_BACKLOG_HISTORY.md#cp25-05)、[CP25-06](PRODUCT_BACKLOG_HISTORY.md#cp25-06) | P2 | 工程待完成；有外部依赖 | 待你验收 |
| 30 | [团队空间、共享、权限与企业管理](#acceptance-team)<br>[CP27-10](PRODUCT_BACKLOG_HISTORY.md#cp27-10)、[CP25-06](PRODUCT_BACKLOG_HISTORY.md#cp25-06)、[CP25-07](PRODUCT_BACKLOG_HISTORY.md#cp25-07) | P2 | 工程待完成；有外部依赖 | 待你验收 |
| 31 | [本地/云隐私、加密与删除控制](#acceptance-privacy)<br>[CP13-10](PRODUCT_BACKLOG_HISTORY.md#cp13-10)、[CP13-07](PRODUCT_BACKLOG_HISTORY.md#cp13-07)、[CP25-07](PRODUCT_BACKLOG_HISTORY.md#cp25-07) | P0 | 工程待完成；含实物验收 | 待你验收 |
| 32 | [设备找回](#acceptance-find_device)<br>[CP20-02](PRODUCT_BACKLOG_HISTORY.md#cp20-02)、[CP27-12](PRODUCT_BACKLOG_HISTORY.md#cp27-12) | P2 | 工程待完成；含实物验收 | 待你验收 |
| 33 | [拾音、续航、存储与便携规格](#acceptance-hardware)<br>[CP27-12](PRODUCT_BACKLOG_HISTORY.md#cp27-12)、[CP24-08](PRODUCT_BACKLOG_HISTORY.md#cp24-08)、[CP27-19](PRODUCT_BACKLOG_HISTORY.md#cp27-19) | P0 | 工程待完成；含实物验收 | 待你验收 |
| 34 | [安装、OTA、正式签名与更新恢复](#acceptance-updates)<br>[CP16-07](PRODUCT_BACKLOG_HISTORY.md#cp16-07)、[CP25-06](PRODUCT_BACKLOG_HISTORY.md#cp25-06) | P0 | 工程待完成；有外部依赖 | 待你验收 |
| 35 | [高级感、信息清晰与完整操作体验](#acceptance-premium_ui)<br>[CP16-05](PRODUCT_BACKLOG_HISTORY.md#cp16-05)、[CP14-08](PRODUCT_BACKLOG_HISTORY.md#cp14-08)、[CP25-04](PRODUCT_BACKLOG_HISTORY.md#cp25-04) | P0 | 工程待完成（已有部分成果） | 待你验收 |
| 36 | [费用、权限、支持和真实购买体验](#acceptance-commercial)<br>[CP25-03](PRODUCT_BACKLOG_HISTORY.md#cp25-03)、[CP25-06](PRODUCT_BACKLOG_HISTORY.md#cp25-06)、[CP25-07](PRODUCT_BACKLOG_HISTORY.md#cp25-07) | P0 | 工程待完成（已有部分成果） | 待你验收 |

### 逐项完成条件与验收动作

次序用于安排推进先后，不把后排能力从最终目标移除。下面动作供Owner验收可用交付；工程负责先完成必要的长会、异常、资源和数据保护验证。

<a id="acceptance-capture"></a>

#### 1. 离线录音、可靠保存和同步恢复

- **原任务：** [CP27-01](PRODUCT_BACKLOG_HISTORY.md#cp27-01)、[CP27-11](PRODUCT_BACKLOG_HISTORY.md#cp27-11)、[CP27-18](PRODUCT_BACKLOG_HISTORY.md#cp27-18)、[CP16-03](PRODUCT_BACKLOG_HISTORY.md#cp16-03)
- **当前情况：** 设备/Windows已有实板记录；044手机文件链已验。新共享FW66675收据另证Android系统/GATT六次加密连接、重连及手机忘记后重配通过；生产App同步、锁屏后台/进程终止接收整链仍开。
- **工程完成条件：** 真实同场长会从开录到双端耐久保存；断连/暂停同步不误停录，失败不丢原音，封口/校验与消费一致。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 用录音卡正常开始一场录音，中途让手机离开或暂停同步，然后继续录音并停止。
2. 回到手机和Windows打开同一场录音，核对开头、断开前后及末尾都能回听，查看保存与接收状态。

**你的结论：** 待你验收

<a id="acceptance-marks"></a>

#### 2. 设备重点、回听及上下文参与整理

- **原任务：** [CP27-17](PRODUCT_BACKLOG_HISTORY.md#cp27-17)、[CP20-01](PRODUCT_BACKLOG_HISTORY.md#cp20-01)
- **当前情况：** 044手机真实FW66674保存样本两处重点读取/回听/TXT已验；实体键→手机接收及重点参与AI整理仍未完整资格。
- **工程完成条件：** 实体重点有持久时间/原音出处，双端可找回/回听；进入整理的重点可追溯，不能只显示列表。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 录音时在两个自己关心的时刻按重点，结束后在手机和电脑找到它们并回听。
2. 查看纪要是否能追溯这些重点；确认设备重点与AI结论有清楚区别。

**你的结论：** 待你验收

<a id="acceptance-call"></a>

#### 3. 手机通话录音与模式切换

- **原任务：** [CP27-02](PRODUCT_BACKLOG_HISTORY.md#cp27-02)、[CP27-12](PRODUCT_BACKLOG_HISTORY.md#cp27-12)
- **当前情况：** 未获当前硬件对实际双方通话的合格证据。
- **工程完成条件：** 按实际支持的手机/通话路径听见双方、标明模式与限制，普通会议不回退；需要的传感器/硬件单列落实。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 在声明支持的手机与通话方式下，完成一段双方对话并保存。
2. 回听双方声音和模式变化，再录一段普通会议，确认不需要猜测当前模式。

**你的结论：** 待你验收

<a id="acceptance-desktop_capture"></a>

#### 4. 线上会议直接采集

- **原任务：** [CP27-03](PRODUCT_BACKLOG_HISTORY.md#cp27-03)
- **当前情况：** Windows双音轨已交付；当前真实会议应用/耳机/静音等完整验收仍有缺口。
- **工程完成条件：** 选择会议音频与本地发言、停止/取消/重开可恢复；不把录音卡环境收音冒充系统音频直采。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 戴耳机参加一次线上对话，选择会议声音和自己的麦克风开始记录。
2. 停止后回听双方发言，查看来源；取消或重新打开后，确认保存状态清楚。

**你的结论：** 待你验收

<a id="acceptance-import"></a>

#### 5. 音视频与文档/图片导入

- **原任务：** [CP27-03](PRODUCT_BACKLOG_HISTORY.md#cp27-03)、[CP27-05](PRODUCT_BACKLOG_HISTORY.md#cp27-05)
- **当前情况：** Windows常见外部音频导入有交付；Android当前普通音频/视频/附件导入用户链未齐。
- **工程完成条件：** 系统选文件/其它App分享进入同一库；原件/来源保留，转码/取消/坏文件/长文件/容量失败明确。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 分别从手机文件、其它App分享和电脑导入自己选择的音视频或支持的资料。
2. 打开、回听或查看内容，再整理和导出；用取消或一个不支持文件检查提示是否清楚。

**你的结论：** 待你验收

<a id="acceptance-notes_images"></a>

#### 6. 文字备注、图片与时间点上下文

- **原任务：** [CP27-05](PRODUCT_BACKLOG_HISTORY.md#cp27-05)、[CP20-05](PRODUCT_BACKLOG_HISTORY.md#cp20-05)
- **当前情况：** 已有备注/人工事项；手机图片附件与统一时间点上下文待补。
- **工程完成条件：** 备注/图片可查看编辑并随会议持久保存/备份/导出；与识别原话分开，AI采用时可追溯。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 给一场会议加一条文字备注和一张图片，并关联到具体位置。
2. 重新打开后检查备注和图片，再备份或导出，确认来源和内容仍在。

**你的结论：** 待你验收

<a id="acceptance-live"></a>

#### 7. 实时转写草稿与会后最终结果

- **原任务：** [CP10-03](PRODUCT_BACKLOG_HISTORY.md#cp10-03)、[CP27-11](PRODUCT_BACKLOG_HISTORY.md#cp27-11)
- **当前情况：** Windows有旧实时路径；手机当前本地完成后转写，完整低等待体验未资格。
- **工程完成条件：** 分别记录会中延迟、录后补传、转写与纪要等待；有中断恢复，不用摘要耗时代替总耗时。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 连接设备进行正常会议，观察会中文字更新和未完成状态。
2. 会议结束后查看最终转写、纪要及各阶段等待时间，核对中途内容没有重复或遗漏。

**你的结论：** 待你验收

<a id="acceptance-asr"></a>

#### 8. 准确转写、长会与资源占用

- **原任务：** [CP11-01](PRODUCT_BACKLOG_HISTORY.md#cp11-01)、[CP11-07](PRODUCT_BACKLOG_HISTORY.md#cp11-07)、[CP20-07](PRODUCT_BACKLOG_HISTORY.md#cp20-07)
- **当前情况：** 已保留产品本地转写与云可选路径；单份61分钟公开开发样本曾为严格字错率3.61%，不能代表跨会/手机/实卡普遍<5%。新联合预训练方案整会准确率、多人/重叠及实际耗时资源门仍未完成；Owner明确早上无外置GPU，当前延后该GPU验证，不把所有AI软件功能都视作不可推进。
- **工程完成条件：** 沿原冻结跨语料整会质量门，中文CER<5%阶段目标及原更高目标保留；计入装载/运行/取消/峰值RAM与CPU，不能把机器卡住。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 使用未参与调试的真实会议，核对开头、中段、结尾及姓名、数字、否定和承诺。
2. 查看对应完整会议准确率、总等待和电脑/手机资源记录，确认可日常使用。

**你的结论：** 待你验收

<a id="acceptance-speakers"></a>

#### 9. 多人区分、姓名与角色确认

- **原任务：** [CP11-03](PRODUCT_BACKLOG_HISTORY.md#cp11-03)、[CP11-04](PRODUCT_BACKLOG_HISTORY.md#cp11-04)
- **当前情况：** Windows已有分人/改名基础，研究模型未通过产品整会门，Android用户链待完整接入。
- **工程完成条件：** 全场身份稳定、逐人文字/时间可核；姓名/角色可人工确认，未知不猜；按原分人/归属指标验收。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 打开一场多人会议，核对同一个人在全场的标签是否一致。
2. 修正姓名和角色后重新打开，检查文字、时间和归属；未知身份应能保持待确认。

**你的结论：** 待你验收

<a id="acceptance-overlap_noise"></a>

#### 10. 噪声与重叠语音处理

- **原任务：** [CP11-04](PRODUCT_BACKLOG_HISTORY.md#cp11-04)、[CP11-07](PRODUCT_BACKLOG_HISTORY.md#cp11-07)、[CP27-12](PRODUCT_BACKLOG_HISTORY.md#cp27-12)
- **当前情况：** 原先分离再逐路识别及说话人条件分离研究保留；未获通用合格方案。
- **工程完成条件：** 遵Owner先分离再逐路转写方向及真实整会/单人不退化对照；难段清楚标示/可选线上，不把降噪更安静当识别合格。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 选一场有背景噪声和重叠发言的真实会议，回听原音与处理结果。
2. 逐人核对重叠内容，并检查普通单人讲话有没有变差；难以识别的地方应明确显示。

**你的结论：** 待你验收

<a id="acceptance-vocab"></a>

#### 11. 个人词表、专名及数字纠正

- **原任务：** [CP20-04](PRODUCT_BACKLOG_HISTORY.md#cp20-04)、[CP11-07](PRODUCT_BACKLOG_HISTORY.md#cp11-07)
- **当前情况：** 有原词表任务；当前手机词表管理与作用到转写的完整链未交付。
- **工程完成条件：** 正确写法/常见误识/语言可管理和备份；新转写应用可验证，不静默重写旧原文。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 添加自己常用的人名、公司名和术语，录一段新的实际对话。
2. 检查新转写的词表效果及旧原文是否保留，再重新打开或恢复词表。

**你的结论：** 待你验收

<a id="acceptance-editing"></a>

#### 12. 转写校对、易读稿与原文定位

- **原任务：** [CP11-03](PRODUCT_BACKLOG_HISTORY.md#cp11-03)、[CP10-04](PRODUCT_BACKLOG_HISTORY.md#cp10-04)、[CP12-06](PRODUCT_BACKLOG_HISTORY.md#cp12-06)
- **当前情况：** 手机已有转写修订/首次原文保留和近似回听；查找替换、完整分人修订等双端一致性待核。
- **工程完成条件：** 去语气词的阅读稿与原始转写分开；修改后引用/定位不串，数字/承诺/否定不被润色改变。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 修改转写中的人名或一句话，并查看原始转写及对应回听位置。
2. 切换易读稿、查找和相关纪要引用，确认修改后来源和原话仍可核对。

**你的结论：** 待你验收

<a id="acceptance-minutes"></a>

#### 13. 结构纪要、结论、行动与事实依据

- **原任务：** [CP12-01](PRODUCT_BACKLOG_HISTORY.md#cp12-01)、[CP12-02](PRODUCT_BACKLOG_HISTORY.md#cp12-02)、[CP12-08](PRODUCT_BACKLOG_HISTORY.md#cp12-08)
- **当前情况：** 结构纪要、来源核对、人工修订、模板与问答/材料入口已有交付；完整真实会议中的漏项、错误结论、负责人/时间和实际会后收益仍待验证，不能仅用生成成功或转写单样本分数关闭。
- **工程完成条件：** 阅读清楚区分事实、决定、建议、待确认项；长会末尾不遗漏，关键结论可回到原文/原音。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 用一场自己的真实会议查看摘要、结论、行动事项和待确认问题。
2. 挑选关键决定与承诺返回原话核对，检查会议末尾、否定条件和建议是否表达准确。

**你的结论：** 待你验收

<a id="acceptance-templates"></a>

#### 14. 场景模板、自定义与多视角结果

- **原任务：** [CP27-04](PRODUCT_BACKLOG_HISTORY.md#cp27-04)、[CP12-09](PRODUCT_BACKLOG_HISTORY.md#cp12-09)
- **当前情况：** Windows原预置/自定义/备份路径保留。Android0.1.47 r2已安装：会议/访谈/课堂、自定义保存再用与同名副本、当前资料绑定/历史保持；真实Android生产存储/整库备份恢复通过。正常App前台回访及真实生成质量按Owner暂停未验。 r2另修正重开旧会议时首选模板被旧纪要视角覆盖的问题。
- **工程完成条件：** 手机/Windows可选会议、访谈、课堂等及自定义模板；保存/再用/恢复/生成历史保持来源，不重写已验Windows实现。 11-05 AI增强对标补充：同场不同模板的命名成果可独立并存，不以当前版本替换或旧版历史冒充多视角成果；默认/自定义整理要求可复用。
- **交付版本：** Android0.1.47/code48 r2（模板软件范围）
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 在手机和电脑选择一个会议场景模板，再创建一个自定义模板。
2. 保存、重新打开并再次使用，检查备份恢复及生成历史，原纪要应可找回。

**你的结论：** 待你验收

<a id="acceptance-qa"></a>

#### 15. 单会/跨会问答和引用

- **原任务：** [CP27-06](PRODUCT_BACKLOG_HISTORY.md#cp27-06)、[CP12-06](PRODUCT_BACKLOG_HISTORY.md#cp12-06)
- **当前情况：** Windows/Android050已接统一会议问答、选定多会范围、原话依据与独立材料保存；053保留相关前端/后端，054补材料选择导出候选。当前缺口为普通手机完整目的使用、真实AI输出质量与取消恢复等全链资格；旧“Android App未接完整问答入口”已过时，不能当尚无入口。
- **工程完成条件：** 选择单会/多会/文件夹范围，答案带可核引用，证据不足明确；删除源后不继续检索，取消/续做/保存笔记可用。 11-05 AI增强对标补充：补手机单会/选定多会/文件夹入口、回答保存为材料、可复用提问任务；选词百科/联网检索与会议原话来源区分，联网为明确按需选择。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 选择一场会议提问，再选择多场或一个资料范围提问。
2. 打开答案中的原文与回听依据，保存有用回答；证据不足、取消或继续处理时应有明确结果。

**你的结论：** 待你验收

<a id="acceptance-translation"></a>

#### 16. 多语言、双语与实时翻译

- **原任务：** [CP27-07](PRODUCT_BACKLOG_HISTORY.md#cp27-07)、[CP12-09](PRODUCT_BACKLOG_HISTORY.md#cp12-09)
- **当前情况：** 已有翻译及手机译文持久化；支持语种、混语、双语/实时与多格式完整资格未齐。
- **工程完成条件：** 按实际语言/入口逐项验收；原文与译文关联/失效/版本/导出清楚，保留未识别/未译范围。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 选择自己使用的语言生成译文，对照人名、数字与关键条件。
2. 修改原文后检查旧译文提示，再重新打开、查看双语并导出。

**你的结论：** 待你验收

<a id="acceptance-mindmap"></a>

#### 17. 思维导图和可用导出

- **原任务：** [CP27-09](PRODUCT_BACKLOG_HISTORY.md#cp27-09)
- **当前情况：** Windows052完整PNG/mm已交付；Android059在实际系统保存、普通分享接收端验证PNG/mm完整文件，文字源/图像已检查；当前061，062源头Word修复不改导图实现。长图交互及完整真实会后用途仍待。
- **工程完成条件：** 同一已保存纪要生成可阅读结构，长图缩放/定位/文字不遮挡，格式可在外部正常打开，不把导图当新事实。
- **交付版本：** Windows0.1.52 installed / Android0.1.53 observed; 0.1.54 candidate not installed
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 打开一份长会议纪要的导图，缩放并找到一个指定分支。
2. 定位相关正文，再导出声明支持的格式，在外部打开核对层级与文字。

**你的结论：** 待你验收

<a id="acceptance-actions"></a>

#### 18. 行动事项、负责人/时间与后续材料

- **原任务：** [CP12-07](PRODUCT_BACKLOG_HISTORY.md#cp12-07)、[CP12-05](PRODUCT_BACKLOG_HISTORY.md#cp12-05)、[CP27-06](PRODUCT_BACKLOG_HISTORY.md#cp27-06)
- **当前情况：** 044手机人工负责人/时间/完成、重开/恢复已验；筛选与跟进材料/提醒闭环待核。
- **工程完成条件：** 任务可核原话、人工安排明确、状态持久；可按负责人/时间/完成筛选并生成可复核跟进草稿，未授权不自动发送。 11-05 AI增强对标补充：补负责人/时间/状态/缺失字段筛选与会后跟进邮件、周报、客户简报/演示提纲等可编辑草稿；普通外发前可核对内容与目标，不编造承诺/负责人。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 把一条事项核对原文后填写负责人、时间并标记完成。
2. 按负责人或状态找回它，重新打开/恢复资料后核对；跟进材料和提醒应与实际选择一致。

**你的结论：** 待你验收

<a id="acceptance-calendar"></a>

#### 19. 日历关联、会议准备和提醒

- **原任务：** [CP12-05](PRODUCT_BACKLOG_HISTORY.md#cp12-05)、[CP27-10](PRODUCT_BACKLOG_HISTORY.md#cp27-10)
- **当前情况：** Windows有TODO/ICS等既有实现；跨端日历账户、提醒与会议准备完整链未齐。
- **工程完成条件：** 关联真实事件/时区/提醒与用户明确动作，冲突取消不重复建；仅生成草稿不冒充已写外部日历。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 把会议或事项关联到一个明确的日历事件，核对时区和提醒。
2. 修改或取消一次安排，检查是否重复创建；会前准备和会后跟进应可打开。

**你的结论：** 待你验收

<a id="acceptance-search"></a>

#### 20. 全库检索与回找依据

- **原任务：** [CP14-07](PRODUCT_BACKLOG_HISTORY.md#cp14-07)、[CP27-06](PRODUCT_BACKLOG_HISTORY.md#cp27-06)
- **当前情况：** Windows有资料检索；041手机标题/原文/纪要本机字面搜索已交付，复杂筛选/跨会智能检索未齐。
- **工程完成条件：** 大库检索能找到目标并返回具体会议/内容/时间；回收站/删源不泄漏旧结果，普通检索可离线。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 在多场会议中查一个记得的词、人名或决定，找到对应场次。
2. 打开命中位置并返回搜索；清除或移走资料后，旧正文不应继续出现在结果里。

**你的结论：** 待你验收

<a id="acceptance-organization"></a>

#### 21. 文件夹、标签、批量管理

- **原任务：** [CP27-08](PRODUCT_BACKLOG_HISTORY.md#cp27-08)
- **当前情况：** Windows已有分类/筛选/批量功能；Android当前主要为平面列表，双端未齐。
- **工程完成条件：** 分类/移动/标签/批量选择持久保存，失败保留选择且不误操作其它录音；备份/恢复不丢组织信息。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 创建分类或文件夹，把几场会议批量移动、加标签并筛选。
2. 重新打开及备份恢复后核对组织信息；取消或失败后应保留正确选择。

**你的结论：** 待你验收

<a id="acceptance-playback"></a>

#### 22. 倍速、定位、续听及静音跳过

- **原任务：** [CP27-14](PRODUCT_BACKLOG_HISTORY.md#cp27-14)、[CP27-25](PRODUCT_BACKLOG_HISTORY.md#cp27-25)
- **当前情况：** Windows已有倍速/续听/A-B等交付；手机当前播放暂停/定位已验，速度/续听等待补齐。
- **工程完成条件：** 位置和原音绑定，速度/续听/关键区间可控；静音跳过不跳掉弱声，未知/缺段不编造时间。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 在一场录音里定位、改倍速、暂停，再重新打开继续回听。
2. 尝试声明支持的区间回听、队列或静音跳过，检查弱声没有被误跳过。

**你的结论：** 待你验收

<a id="acceptance-trim_merge"></a>

#### 23. 非破坏剪辑、切分和合并

- **原任务：** [CP27-16](PRODUCT_BACKLOG_HISTORY.md#cp27-16)
- **当前情况：** 保护与回收站已有Windows实现；完整非破坏裁剪/合并用户链未交付。
- **工程完成条件：** 原音保留，派生时间映射正确；取消/失败不改源；多源合并仍标原身份与来源。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 在副本上裁剪或切分，再合并两份会议资料。
2. 比较原音与派生内容、时间和来源，重新打开后确认原件仍可找回。

**你的结论：** 待你验收

<a id="acceptance-trash"></a>

#### 24. 保护、回收站与明确清除

- **原任务：** [CP27-27](PRODUCT_BACKLOG_HISTORY.md#cp27-27)、[CP13-02](PRODUCT_BACKLOG_HISTORY.md#cp13-02)
- **当前情况：** Windows原已交付；Android069新增保护/回收站/恢复及明确范围清除，候选已生成与后台核对，未装手机/未实际验收。
- **工程完成条件：** 普通删除可恢复原内容，永久清除范围/确认清楚；共享原件、活动录音和保护项不误删。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 给一场测试录音加保护，尝试删除，再对普通测试录音移入回收站并恢复。
2. 检查恢复后的原音、文字和备注；永久清除应有明确范围及结果。

**你的结论：** 待你验收

<a id="acceptance-exports"></a>

#### 25. 按内容/格式导出、复制与分享

- **原任务：** [CP27-09](PRODUCT_BACKLOG_HISTORY.md#cp27-09)、[CP12-04](PRODUCT_BACKLOG_HISTORY.md#cp12-04)、[CP14-08](PRODUCT_BACKLOG_HISTORY.md#cp14-08)
- **当前情况：** Windows067已安装，原245文件不变；八格式实际系统保存/取消/内容通过，复制文字匹配。普通App真实系统分享打开后显示无法列出共享方式；资源管理器同公开PDF可列本机接收应用，正常Windows环境仍失败，根因待定位。最小原生窗口对照被Owner物理Esc停止，未发文件。Android066合并Word候选待共享手机释放后实验，原音/SRT/AI填外部表样及完整交付仍开。
- **工程完成条件：** 原音/原文/纪要/译文可分别选，所需MP3/WAV/TXT/MD/DOCX/PDF/SRT/XLSX/导图格式逐项核内容与外部打开；PDF中文复制/搜索须正确。 11-05 AI增强对标补充：另区分普通转写文件导出与AI材料交付：按既有Word/Excel表样填字段、演示提纲PDF/PPTX及生成图PNG；未接AI/附件/格式真实链就保留未完成，不把普通DOCX或XLSX导出当智能填表已完成。
- **交付版本：** Windows0.1.52 installed / Android0.1.53 observed; 0.1.54 candidate not installed
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 分别选择原音、转写、纪要和译文，按需要导出支持的格式。
2. 在外部打开文件；复制并搜索中文、人名和数字，核对时间/说话人/重点选项，再取消一次保存。

**你的结论：** 待你验收

<a id="acceptance-backup"></a>

#### 26. 完整备份、换机恢复与版本

- **原任务：** [CP14-06](PRODUCT_BACKLOG_HISTORY.md#cp14-06)、[CP14-01](PRODUCT_BACKLOG_HISTORY.md#cp14-01)
- **当前情况：** Windows已有备份，043/044手机备份恢复/切回原库实际通过；实体换机/双端互通未齐。
- **工程完成条件：** 录音/文字/人工事项/译文/历史/模板/组织信息整体保留，校验后非覆盖恢复；实际换设备验证，不仅同机。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 给测试会议加入人工事项、译文、历史、模板或分类后保存完整备份。
2. 在新资料库或另一台支持的设备恢复，逐项核对内容，再切回原资料确认没有覆盖。

**你的结论：** 待你验收

<a id="acceptance-cross_platform"></a>

#### 27. 账号、跨端同步和客户端覆盖

- **原任务：** [CP27-10](PRODUCT_BACKLOG_HISTORY.md#cp27-10)、[CP16-06](PRODUCT_BACKLOG_HISTORY.md#cp16-06)、[CP16-09](PRODUCT_BACKLOG_HISTORY.md#cp16-09)
- **当前情况：** Windows/Android已交付；共享云库/账号恢复、iOS/Web等当前未有整套交付证据。
- **工程完成条件：** 同一资料在支持平台一致，冲突与离线编辑可恢复，账号注销/数据去向明确；本地路径继续可用，私密原音不擅自上传。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 在声明支持的两个客户端打开同一场资料，并做一次离线修改。
2. 重新连接后核对冲突、原音与版本，再验证账号恢复和本地使用路径。

**你的结论：** 待你验收

<a id="acceptance-automation"></a>

#### 28. 自动同步整理与可复用工作流

- **原任务：** [CP27-11](PRODUCT_BACKLOG_HISTORY.md#cp27-11)、[CP27-04](PRODUCT_BACKLOG_HISTORY.md#cp27-04)、[CP27-06](PRODUCT_BACKLOG_HISTORY.md#cp27-06)
- **当前情况：** 已有部分自动接收/整理基础；完整用户可配工作流与跨工具完成结果待补。
- **工程完成条件：** 明确选择触发/服务/范围，失败可继续且不重复处理；生成/外发分别可见，不把自动化按钮当执行成功。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 选择一个自动接收、整理或后续工作流，明确触发与处理范围。
2. 观察一次正常完成及失败后继续，检查没有重复执行，外发动作能先复核。

**你的结论：** 待你验收

<a id="acceptance-integrations"></a>

#### 29. 日历、笔记、CRM与API/MCP集成

- **原任务：** [CP27-10](PRODUCT_BACKLOG_HISTORY.md#cp27-10)、[CP25-05](PRODUCT_BACKLOG_HISTORY.md#cp25-05)、[CP25-06](PRODUCT_BACKLOG_HISTORY.md#cp25-06)
- **当前情况：** 现有本地后端/CLI不等于普通用户第三方集成；逐服务账户、权限与结果未核完。
- **工程完成条件：** 按目标工具逐个接通真实授权与撤销/错误路径；写入前可复核，不能虚构集成成功或服务套餐。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 连接声明支持的日历、笔记或其它工具，完成一次自己需要的资料流转。
2. 查看外部真实结果，再撤销授权或取消动作，检查状态和重试是否清楚。

**你的结论：** 待你验收

<a id="acceptance-team"></a>

#### 30. 团队空间、共享、权限与企业管理

- **原任务：** [CP27-10](PRODUCT_BACKLOG_HISTORY.md#cp27-10)、[CP25-06](PRODUCT_BACKLOG_HISTORY.md#cp25-06)、[CP25-07](PRODUCT_BACKLOG_HISTORY.md#cp25-07)
- **当前情况：** 当前产品以本地单人路径为主；团队库/评论/链接权限/SSO等未获交付证据。
- **工程完成条件：** 共享范围/角色/撤销/历史/成员离开与资源管理真实工作；企业要求保留在总对标范围，不以个人版通过代替。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 用不同角色在测试团队共享一份资料，尝试查看、评论或编辑。
2. 撤销共享或移除成员后核对可访问范围；需要的企业登录和管理入口分别验收。

**你的结论：** 待你验收

<a id="acceptance-privacy"></a>

#### 31. 本地/云隐私、加密与删除控制

- **原任务：** [CP13-10](PRODUCT_BACKLOG_HISTORY.md#cp13-10)、[CP13-07](PRODUCT_BACKLOG_HISTORY.md#cp13-07)、[CP25-07](PRODUCT_BACKLOG_HISTORY.md#cp25-07)
- **当前情况：** 已有配对/本地保存/清理边界；原音静态加密、账号云管理与实际安全资格未全齐。
- **工程完成条件：** 传输/静态保护各自实测，用户明确决定外部处理；保留期/删除/钥匙恢复可理解；认证只能按实际取得证明。 11-05 AI增强对标补充：Android048当前密钥仅内存保存、重开重填。后续补平台保护的可选择安全保存/清除与连通状态，保持密钥不入备份、原音不擅自上传；不靠隐藏开关默认开启云端。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 查看本地与外部处理的选择、数据位置、费用和保留说明。
2. 对测试资料执行导出、删除和账户/设备相关恢复，核对可见结果与工程安全证据范围。

**你的结论：** 待你验收

<a id="acceptance-find_device"></a>

#### 32. 设备找回

- **原任务：** [CP20-02](PRODUCT_BACKLOG_HISTORY.md#cp20-02)、[CP27-12](PRODUCT_BACKLOG_HISTORY.md#cp27-12)
- **当前情况：** 原蓝牙范围找设备任务保留；Apple Find My平台接入未获资质或硬件证据。
- **工程完成条件：** 本地范围提示实际可用；若覆盖Find My需完成相应平台/硬件/认证，不能用应用图标冒充系统找回。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 在实际支持的平台尝试找回测试设备，核对范围、位置或提示是否真实。
2. 设备不在可用范围时检查未知/不可用状态；若声明系统级找回，应能在对应平台实际使用。

**你的结论：** 待你验收

<a id="acceptance-hardware"></a>

#### 33. 拾音、续航、存储与便携规格

- **原任务：** [CP27-12](PRODUCT_BACKLOG_HISTORY.md#cp27-12)、[CP24-08](PRODUCT_BACKLOG_HISTORY.md#cp24-08)、[CP27-19](PRODUCT_BACKLOG_HISTORY.md#cp27-19)
- **当前情况：** 当前对象是Companion现板，屏幕拔下运行无屏配置只验证共用核心；已有实板录音/同步/OTA与66685指定删除证据。现板原音可懂度/远场、真实电池采样/充电/低电保存/电流续航和整机可靠性仍开。Capture新板在独立产品目录、尚未到板；不把新板适配计为当前Companion已交付或混作同一售卖范围。
- **工程完成条件：** 真实姿态/噪声/距离、连续录音与存储、充电/低电/唤醒逐项有证据；功能/结果等价需真实满足，不能照搬宣传数值。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 按声明的实际场景使用设备，检查开停、唤醒、充电、低电和录音保存。
2. 核对工程提供的实际续航/存储/拾音记录及未覆盖条件，实际效果与规格说明应一致。

**你的结论：** 待你验收

<a id="acceptance-updates"></a>

#### 34. 安装、OTA、正式签名与更新恢复

- **原任务：** [CP16-07](PRODUCT_BACKLOG_HISTORY.md#cp16-07)、[CP25-06](PRODUCT_BACKLOG_HISTORY.md#cp25-06)
- **当前情况：** Windows060实装及原245文件一致；Android最新共享观察065，066合并候选未装。本侧复用064/FW66688普通OTA指标与原34目录保持通过证据，不重复升级；最新收取速度、恢复资格、清配对和正式签名等原范围仍沿原待办。
- **工程完成条件：** 正式身份、升级/失败恢复、数据保留与下载渠道可供普通用户完成；工程包不当正式售卖包。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 通过正式提供的入口安装或更新，重新打开原有会议。
2. 核对版本、资料及正常录音；查看更新失败时的恢复与求助方式。

**你的结论：** 待你验收

<a id="acceptance-premium_ui"></a>

#### 35. 高级感、信息清晰与完整操作体验

- **原任务：** [CP16-05](PRODUCT_BACKLOG_HISTORY.md#cp16-05)、[CP14-08](PRODUCT_BACKLOG_HISTORY.md#cp14-08)、[CP25-04](PRODUCT_BACKLOG_HISTORY.md#cp25-04)
- **当前情况：** 已多轮统一UI及真机局部改进；客户完整会后用途、AI增强发现/操作与双端一致性仍需实用验证。
- **工程完成条件：** 深浅色、详情/来源/任务/导图/翻译/设置均有可用状态；正常/空/忙/失败/恢复、键盘/长文/可访问性和性能一致；普通客户自选完整目的体验。 11-05 AI增强对标补充：本轮定位的Windows模型启用开关与Android密钥/服务设置负担需收敛。普通入口按纪要、问答和材料组织，当前模板轻量选择，专业模型配置下沉；联网/云端/自动行为保留明确控制。这里只完成官方研究，未改界面或安装。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 在手机和电脑按自己的目的完成找会议、看纪要、核对、修改和分享。
2. 检查深浅色、长文、键盘及加载/失败后的操作，记录看不懂、不好找或不愿继续用的具体位置。

**你的结论：** 待你验收

<a id="acceptance-commercial"></a>

#### 36. 费用、权限、支持和真实购买体验

- **原任务：** [CP25-03](PRODUCT_BACKLOG_HISTORY.md#cp25-03)、[CP25-06](PRODUCT_BACKLOG_HISTORY.md#cp25-06)、[CP25-07](PRODUCT_BACKLOG_HISTORY.md#cp25-07)
- **当前情况：** 实际售后、正式服务/许可/价格边界仍未齐，AI模拟没有真人订单。
- **工程完成条件：** 真实公布提供内容/费用/限制、服务与售后；软件许可/分发条件实际核对，不能借用竞品认证/承诺；真人使用反馈和成交分开。 11-05 AI增强对标补充：自备密钥模式与正式托管AI服务/套餐需明确区分；当前尚无默认托管服务交付证据，不能改个按钮就当普通消费者可直接使用。竞品付费/额度/平台限制保留核对。
- **交付版本：** 本项整体交付待完成；既有成果见当前情况
- **验收准备：** 工程提供可检查的交付版本、可用入口和明确支持条件后进行；优先使用测试资料，原有资料保留。

你可这样验收：

1. 按普通客户方式查看购买内容、费用、服务限制和使用说明。
2. 尝试找到真实支持入口，核对售后与资料处理条件；真实购买与模拟体验分别记录。

**你的结论：** 待你验收


## 嵌入式当前待办

由同一份 product_backlog.json 的 owner_module_execution.embedded 生成。

**当前 3 个工作包，均为本侧录音卡工作。** 另有 11 组已验能力、3 组后置范围。原工程编号仅作追溯，不把它们当成当前未完成数。

当前继续交付Companion共用录音核心与普通App可用性；Capture新板未到，只建独立产品仓库，不开展Capture硬件验收。

### 当前交付基线

- 已保存实板记录：FW66702 / UI85；这不是实时接板查询。
- 当前源码：`C:\Users\Billy\Desktop\Denzic\Companion\firmware-recovery`，固件改动提交 `a43893f4cf7e684f7577728ea69f52655ce479a3`。
- 构建入口：`python tools/build_current_firmware.py --show`。构建参数配方参考版 66685，与已装版本分开显示。
- 安装证据：[C:\Users\Billy\Desktop\Denzic\Companion\docs\handoffs\20261106-companion-device-management\full-media66702\ordinary-phone080-ota.json](C:\Users\Billy\Desktop\Denzic\Companion\docs\handoffs\20261106-companion-device-management\full-media66702\ordinary-phone080-ota.json)。

### 现在推进什么

| 工作包 | 分类 / 责任 | 真实剩余 |
|---|---|---|
| 资源可靠性与电源验收 | 受阻 / 软件栈/休眠计时已收尾；电源实测受阻 / 本侧 | 电量raw0..2与DMM4.047V不符，原因未定位；按Owner要求先挂起，保留旧可读及两次对照证据。；充电接入/拔出与PG/STAT实物对照；当前无USB充电线，不能把上拉确认当充电验收。；低电阈值与录中低电封口的真实电源验证；ADC和可控供电条件未齐，原功能/模型保留。；万用表实测空闲、自动深睡、录音和同步电流，给出测量条件及续航范围；Owner明确无法测，先后置，不再催接线或拿深睡统计当实测。 |
| 当前手机配对与正常加密连接 | 当前App崩溃修复已实际使用；冷5秒单样本过，自动恢复10秒仍待改善 / 本侧 | 自动同任务恢复≤10秒当前未达，先按真实时间链定位；不靠新START、清配对或手动救回。；正常冷连接≤5秒目前一次通过，不冒称所有手机兼容或长期全过。 |
| 当前普通升级与传输指标 | 正常OTA达体验门；完整录音成立，动态停录可用等待待优化 / 本侧 | 任意长度录音STOP至完整音频按8秒+未同步编码/50KiB/s+待生成音频/5MiB/s动态验；下一实测在STOP快照准确剩余字节/部分前缀，不只测五分钟。原27327.768秒在动态约22.278秒未达；速率仍50。；自动恢复≤10秒沿CP09-02；修受影响当前链路后再做必要一次最终两小时。；下一实际交付关闭临时CPU诊断，恢复应用412216B/静态69328B原预算；不为CPU百分比单独构建。；Windows077日用包仍未交付，原构建内存依赖不变；原明确电源/声学/实体首字/生产/屏幕范围保留。 |

#### 资源可靠性与电源验收

- 已有：FW66677正常OTA已装。修复旧120秒慢359ms的短眠计时偏差；新版119993ms在完整测量窗口内，6513次短眠/恢复失败0，醒后9.08秒/两标记完整收取。当前编码前台栈18428B/预留21504B，实际录中同步最低空闲4304B；新版编码栈相同。
- 下一步：待采样通路、充电/可控低电及电流测量条件具备，继续对应实物验收。120秒计时通过不替代长期精度或续航。
- 交付结果：软件栈复核及短眠计时修复已验；电压、充电、低电保存与真实耗电仍需实物验证，条件未具备不关闭整包。
- 原任务：[CP21-03](PRODUCT_BACKLOG_HISTORY.md#cp21-03)、[CP21-04](PRODUCT_BACKLOG_HISTORY.md#cp21-04)、[CP24-08](PRODUCT_BACKLOG_HISTORY.md#cp24-08)、[CP27-19](PRODUCT_BACKLOG_HISTORY.md#cp27-19)

#### 当前手机配对与正常加密连接

- 已有：App080将真实DeadObject系统异常转既有LinkFailure。279蓝牙关闭36秒未再崩溃，同原任务自动恢复，原音全部核对；普通暂停续传3.188秒过，冷连接4.267秒过一次。自动恢复保守10.735秒未证新10秒门，首次133现象仍保留。
- 下一步：沿embedded.next。
- 交付结果：新手机在正常有限配对窗口内完成配对和加密目录访问，失败可恢复；不清其它绑定，不读取原录音。
- 原任务：[CP09-02](PRODUCT_BACKLOG_HISTORY.md#cp09-02)

#### 当前普通升级与传输指标

- 已有：702/080正常签名OTA55.085KiB/s/117.474秒/传后91.906秒，WSI4和旧34/4608000B/17核对。279517.58秒/5段1088106B、一次START/STOP和全部CRC/SHA/连续样本/WAV10ms通过，异常0，栈最低4272/guard0/low0。原274两小时完整性/零断链成立，旧耗时超参考留存。
- 下一步：沿embedded.next。
- 交付结果：实际完整签名升级、正确版本/资源/哈希/临时区释放与旧目录核对通过，并达到当前正常传输/资源指标。
- 原任务：[CP23-10](PRODUCT_BACKLOG_HISTORY.md#cp23-10)

### 当前指标验收

数值唯一来源：`product_backlog.json#/quality_targets/embedded_current_20261106`。功能通过不能抵消指标失败；缺测不能记通过。

保持61.44MHz/既有快传，普通有效速度50KiB/s；CPU只观测，不单独追数字。
冷5秒/同任务恢复10秒/控制400ms/首PCM1.5秒；停止至完整音频按8秒+剩余编码字节/50KiB/s+待生成完整音频字节/5MiB/s，所有长度统一。速度50、CPU仅观察。

| 指标 | 当前要求 | 最近实测 | 判定 |
|---|---|---|---|
| 设备确认有效载荷速度 | ≥50 KiB/s | 55.085 | 通过 |
| 正常完整升级总耗时 | ≤150 s | 117.474 | 通过 |
| 传完至安装后核对耗时 | ≤100 s | 91.906 | 通过 |
| 本批固件应用大小 | ≤412216 B | 413672 | 失败 |
| 本批data+bss | ≤69328 B | 69416 | 失败 |
| 本批预留栈 | ≤21504 B | 21504 | 通过 |
| 观测范围内栈防护/低栈告警 | ≤0 count | 0 | 通过 |
| 旧录音目录非预期变化 | ≤0 count | 0 | 通过 |
| 升级后未释放临时空间 | ≤0 B | 0 | 通过 |
| UID/版本/资源/有效载荷校验不匹配 | ≤0 count | 0 | 通过 |

当前0.1.84/FW66702；083实机60.54/300.42秒动态8.816/18.866≤10.865/22.172，五分钟50.396KiB/s；084十秒7.876/6.906≤8.506/8.500。083暂停续收3.312秒、084冷4.624秒通过。短录严格含回收速率仍失败，radio旧10.735秒>10、正式资源/最终长期未关闭；不把CPU观测当硬门。

#### 已有嵌软要求继续保留

- **QM01 / 连续录音：** 正常宠物界面及BLE工作时连续30分钟为中间门、两小时为最终长录门；离线录音及录中上传分别满足采音overflow/stale/reject/deadline均0，完整录音解码时长与设备目录差≤40ms。
- **QM02 / 原音与恢复：** 正常链音频帧丢失0、最终CRC/SHA一致100%；已成功落盘完整帧可恢复；本机原音/WAV/索引耐久前消费次数0。
- **QM03 / 传输与重连：** 停止录音至完整原音/App音频/索引与精确设备确认采用embedded_current_20261106.dynamicDeadlines.recording_completion动态预算，按剩余未同步编码及待生成音频量，不只五分钟。持续有效负载至少录音生产率4倍；正常已配对同任务恢复≤10秒，不重新开录。
- **QM10 / 实时采音、编码与调度余量：** 每20ms音频包Opus编码P95≤5ms、峰值≤6ms；每10ms麦克风转换峰值≤3ms，恢复原工程预算。正常界面/蓝牙并发未服务采音间隔≤8ms与原10ms硬保护保留；零漏音/溢出/过期/拒绝/期限/IRQ异常和完整原音是必需。内部耗时用于根因定位，不为数字单独收紧或代替真实用户体验。
- **QM12 / 连接等待与录音操作响应：** 正常已配对指定设备冷连接至私有目录可用≤5秒；同一保留连接START/STOP/重点实际ACK≤400ms，正常工作区START到首个真实PCM≤1.5秒；结束收取后只读再次连接≤10秒。首次配对/布局初始化及系统无线不可用区间单列，正常重试耗时计入。
- **QM14 / MCU与内存余量：** Owner2026-11-07：撤回新增CPU<90%硬门，不为CPU数字单独继续优化或阻断交付；CPU占用保留工程观察，旧95/90合同和有效性失败保留。以真实零漏音/溢出/卡顿、控制响应和完整收取验用户影响。当前已验21504B栈布局、动态水位与stack_low/guard=0、应用412216B/静态69328B预算保持；不扩大缓存/栈掩盖问题。屏幕仍暂停。
- **QM15 / 蓝牙基础与稳定恢复：** 已配对同设备正常两小时录音会话非预期断链0；主动断链后≤10秒恢复同一录音并从耐久校验游标续传，重复开录0、未耐久消费0、坏CRC/SHA接受0。未加密读取私有音频/未确认重绑放行0，人工断开保持优先。

### 本次补查与优化次序

补入4项P1日常可用性工作和2项P2收益驱动优化。开录日期是已确认实现缺口；容量/恢复/标记已有底层，按入口和未覆盖体验补齐，不当从零重写。

| 次序 | 原任务 | 当前缺口与下一结果 |
|---|---|---|
| P1-1 / 离线录音日期与可信校时 | [CP04-05](PRODUCT_BACKLOG_HISTORY.md#cp04-05)、[CP07-05](PRODUCT_BACKLOG_HISTORY.md#cp07-05) | FW66679及已装Android0.1.49交付完整开录日期；实板日历目录、录中回拨、正常OTA后同日期、两端134240样本/2重点及新进程重读通过，33条旧日期仍未知。Windows私有同源原生收取已验，正式桌面包沿前端交付。 嵌软本项关闭；RTC掉电/跨日/回拨软件模型及原物理按键证据按范围保留，正式Windows安装包由现有前端交付承接。 |
| P1-2 / 无屏换手机、清配对与恢复设置 | [CP13-08](PRODUCT_BACKLOG_HISTORY.md#cp13-08)、[CP09-02](PRODUCT_BACKLOG_HISTORY.md#cp09-02)、[CP04-06](PRODUCT_BACKLOG_HISTORY.md#cp04-06) | 实板恢复默认/重复恢复、清4配对再加密重配1、34目录/日期不变；66682正常OTA后默认值/新配对均保留；66683录中恢复明确BUSY且设置未变。 嵌软协议范围关闭；普通App恢复设置/清配对入口仍沿前端当前050/051任务合入并验收，工程脚本不等于用户入口。 |
| P1-3 / 无屏状态、容量与指示灯软件策略 | [CP04-01](PRODUCT_BACKLOG_HISTORY.md#cp04-01)、[CP02-03](PRODUCT_BACKLOG_HISTORY.md#cp02-03)、[CP07-01](PRODUCT_BACKLOG_HISTORY.md#cp07-01)、[CP07-05](PRODUCT_BACKLOG_HISTORY.md#cp07-05)、[CP27-17](PRODUCT_BACKLOG_HISTORY.md#cp27-17)、[CP27-18](PRODUCT_BACKLOG_HISTORY.md#cp27-18) | 正常有限查询已正确输出CAPTURE1；FW66683首次录音成功回执已有10ms有效PCM，已停止/原音保存/标记耐久沿实际结果；生产容量/满盘模型沿原证据。 现16MiB样板空盘离线几何预算约120分钟，不是电池续航或已实测两小时；已验三小时在线循环不等于纯离线容量。 软件与现板查询范围关闭；普通App展示沿现有前端集成，新Capture板LED按原明确硬件block续作。 |
| P1-4 / 开录响应、第一句话和标记时机 | [CP04-01](PRODUCT_BACKLOG_HISTORY.md#cp04-01)、[CP05-01](PRODUCT_BACKLOG_HISTORY.md#cp05-01)、[CP05-05](PRODUCT_BACKLOG_HISTORY.md#cp05-05)、[CP27-17](PRODUCT_BACKLOG_HISTORY.md#cp27-17) | 复现实际缺陷：mic启动但0有效PCM即报录音中；d3afe95修正后生产开停/暂停继续/本地控制模型通过。FW66683实板首次成功已有10ms采样，5.21秒完整83360样本，一枚重点在18880样本/源轴1.18秒处，日期一致、精确收取回收；旧34目录不变。 软件成功时机和持久标记范围已验；Owner明确实体冷/睡眠首录与第一句话回听稍后再做，先不再催操作，不新增重启排查。 |
| P2-1 / Capture无屏RAM和升级资源裁剪 | [CP21-03](PRODUCT_BACKLOG_HISTORY.md#cp21-03)、[CP23-10](PRODUCT_BACKLOG_HISTORY.md#cp23-10)、[CP25-05](PRODUCT_BACKLOG_HISTORY.md#cp25-05) | FW66684已装并验：Capture编译期去掉不用的renderer及256B图像缓存，实际M33结构7952→7424B、静态RAM省528B，应用409116→408996B（省120B），SRAM1余量6520→7048B，预留栈未增；资源CRC/日期/配对/新原音/精确收取及34旧目录不变通过。有屏完整构建通过，编译边界修正前后有屏镜像逐字节相同。 本项当前旧板兼容范围关闭；保留presenter诊断状态与950272B UI联合包，不为剩244B或包体另起Boot/布局迁移。新板独立资源边界随原硬件/生产适配再定。 |
| P2-2 / 录音与屏幕职责解耦 | [CP04-01](PRODUCT_BACKLOG_HISTORY.md#cp04-01)、[CP25-05](PRODUCT_BACKLOG_HISTORY.md#cp25-05) | 实际资源修改将renderer、绘图回调/帧提交及缓存限定在有屏编译分支；Capture/Companion仍同一核心，录音/存储/连接所有者和poll顺序保留。未引入新状态机、堆分配或复制产品分支。 本轮必要职责边界随RAM裁剪完成；其余底层已有回调边界，当前没有证据支持仅为文件长而重写整合调度。后续有真实功能变更再局部抽取。 |
| P1-5 / 用户主动删除不需要的设备录音并释放空间 | [CP07-09](PRODUCT_BACKLOG_HISTORY.md#cp07-09)、[CP13-05](PRODUCT_BACKLOG_HISTORY.md#cp13-05) | cfedd31/FW66685正常OTA与选场取消/删除/回收后再录通过，应用409252B（+256B）、常驻RAM无增。Windows普通053/2ba08c56实机Cancel保留、选删回收、目录即时更新均通过；最终34旧元数据逐条不变，剩余4608000B。先前“worker未绑定”的审查误判已纠正，复用原worker与packet；手机用户链仍未通过。 Android055普通系统配对/逻辑目录已验，e6删除后目录和空间恢复；e7真实点击取消后仍保留，再仅收e7到手机4754B原音SHA匹配并精确消费，34旧目录逐条一致、原空间4608000B恢复。首个e6确认点击者未观察，不当取消成功；e7取消有实际输入和结果。 本批设备/Windows隔离候选/已装Android055范围通过；不重复这些路径，日用Windows合并发布沿前端原批次。继续当前手机远程开录缺陷、维护和OTA，不把它们藏进本项关闭。 |
| P1-6 / 从设备列表选择一场优先收取 | [CP09-04](PRODUCT_BACKLOG_HISTORY.md#cp09-04)、[CP09-05](PRODUCT_BACKLOG_HISTORY.md#cp09-05)、[CP27-11](PRODUCT_BACKLOG_HISTORY.md#cp27-11) | Windows普通列表“接收这场”仅收新e5，2040ms/32640有效样本耐久保存校验并精确回收；未选34旧目录保持，暂停自动同步选择未改变。Android已有原整场接收后端，53逻辑场次入口待实机配对后确认。 Android055普通系统配对/逻辑目录已验，e6删除后目录和空间恢复；e7真实点击取消后仍保留，再仅收e7到手机4754B原音SHA匹配并精确消费，34旧目录逐条一致、原空间4608000B恢复。首个e6确认点击者未观察，不当取消成功；e7取消有实际输入和结果。 本批设备/Windows隔离候选/已装Android055范围通过；不重复这些路径，日用Windows合并发布沿前端原批次。继续当前手机远程开录缺陷、维护和OTA，不把它们藏进本项关闭。 |
| P1-7 / 手机独立完成设备恢复设置与固件升级 | [CP13-08](PRODUCT_BACKLOG_HISTORY.md#cp13-08)、[CP04-06](PRODUCT_BACKLOG_HISTORY.md#cp04-06)、[CP23-08](PRODUCT_BACKLOG_HISTORY.md#cp23-08) | Android055/a39c44ed与后端8e8a82c已安装，普通系统配对和目录实际通过。维护及OTA源码/主机协议检查已完成，66686正常签名整包可用；手机切回其它应用前未开始OTA，不把原生状态检查当真实升级通过。 手机接回且Owner方便时，集中做普通恢复/清配对与66685→66686签名整包OTA并读回实际运行版本；已装056不等于OTA已验。当前不催手机，推进实际可独立任务，原设备协议/WindowsOTA证据沿用。 |

#### 竞品参考与取舍

- [Plaud NotePin S：指示灯状态](https://support.plaud.ai/hc/en-us/articles/53639001483545-Indicator-light)：无屏录音、标记、满盘等状态要有可理解反馈；不照搬灯色或增加振动。
- [Plaud：找回录音与时间异常](https://support.plaud.ai/hc/en-us/articles/63429909647257-File-missing-in-the-Plaud-Mobile-App-for-v4-0-x-or-later)：日期异常会影响找回录音；支持录音日期来源/未知状态补全。
- [Plaud：解绑设备](https://support.plaud.ai/hc/en-us/articles/63429895998617-Unbind-a-device-from-your-account-for-v4-0-x-or-later)：解绑/清除作用须明确；其未同步录音删除策略不直接采用。
- [soundcore Work：离线保存、换手机与回放](https://service.soundcore.com/article-description/soundcore-Work-FAQ)：离线保存在设备、连接后同步是基础能力；回放可在手机，不给Capture增加扬声器。
- [soundcore Work：快捷录音与重点标记](https://www.soundcore.com/soundcore-work-ai-voice-recorder)：参考直接开录和重点标记收益；保留Owner已定长按/短按，不为竞品双击再改当前手势。
- [soundcore Work：数据与换机说明](https://service.soundcore.com/article-description/How-do-I-avoid-losing-soundcore-Work-recording-data)：说明容量和换机的数据去向；其满盘覆盖未转移内容的策略不采用。

#### 已有能力与保持后置的范围

- 离线开停录、原音耐久保存、实体短按标记、切段同会话、断链续录/续传、满盘封口、正常OTA已有代码和范围明确的实板证据，直接复用。
- 暂停/继续沿软件端现有命令，当前实体短按仍为标记；不重新加入暂停手势。
- 新Capture只用指示灯，不加振动；现有按键方案保持。
- 原6项明确blocked保持原原因和恢复条件，软件反馈策略可先做，真实LED/ADC/低电/电流不虚关。
- 音质仍是重要未合格范围：既有增益/滤波/双麦试验未改善。保留CP05-04结论和Owner后置，不重开同条件DSP/ASR试验。
- 声控、预录、预约/延时录音、脱离手机的设备列表保留原后置增强；Capture没有屏幕/回放硬件，不自动加菜单/扬声器。
- 通话振动传感器、Wi-Fi高速链路、USB音频/文件盘、Find My网络和蓝牙耳机录音依赖硬件/芯片/认证，不列为当前WBA55纯软件缺陷。
- 云端转写、摘要、翻译、搜索、回收站和分享沿原前后端模块；不重复建嵌软任务。

### 本轮已收尾工作包

- **连接变化后继续录音并恢复原会话：** FW66667实板：系统蓝牙关闭后同会话208继续录音，182.8秒原音完整保存；复用暂停同步/进程退出结果。自然距离归同一软件断链路径，射频覆盖另项。 [证据1](<E:/CodexData/Companion/capture-core-closeout-20261104/radio-loss-r2/acceptance.json>)、[证据2](<E:/CodexData/Companion/recording-recovery-20261104/receive205/resume-result.json>)、[证据3](<E:/CodexData/Companion/recording-recovery-20261104/sync-pause-live-r1/result.json>)、[证据4](<E:/CodexData/Companion/recording-recovery-20261104/receiver-exit-live-r1/result.json>)
- **录音存储异常正确收尾并可继续使用：** 关闭实际空间耗尽/回收后普通再录与本批响应缺陷。物理介质故障/录中掉电、两小时并发、首字听感及整机电源资格不在此关闭范围；旧模型关闭、真实失败和原指标均保留。 [证据1](<C:\Users\Billy\Desktop\Denzic\Companion\docs\handoffs\20261106-companion-device-management\full-media66690\full-stop.json>)、[证据2](<C:\Users\Billy\Desktop\Denzic\Companion\docs\handoffs\20261106-companion-device-management\full-media66690\full-receiver-windows067.json>)、[证据3](<C:\Users\Billy\Desktop\Denzic\Companion\docs\handoffs\20261106-companion-device-management\full-media66691\actual-full-and-restart.json>)、[证据4](<C:\Users\Billy\Desktop\Denzic\Companion\docs\handoffs\20261106-companion-device-management\full-media66693\control-latency.json>)、[证据5](<C:\Users\Billy\Desktop\Denzic\Companion\docs\handoffs\20261106-companion-device-management\full-media66693\final-idle.json>)
- **Companion录音核心与当前无屏使用配置补全：** 当前实际共存与普通操作范围，不外推全部RF环境或硬件功耗/声学/生产资格。 16B必要修复预算明确变更，旧零增长FAIL保留；实体按键未在本批重验，串口开窗辅助已标明。 [证据1](<C:\Users\Billy\Desktop\Denzic\Companion\docs\handoffs\20261106-companion-device-management\phone065-recording235-metric-verdict.json>)、[证据2](<C:\Users\Billy\Desktop\Denzic\Companion\docs\handoffs\20261106-companion-device-management\phone065-ota66689-revised-resource-verdict.json>)、[证据3](<C:\Users\Billy\Desktop\Denzic\Companion\docs\handoffs\20261106-companion-device-management\phone065-maintenance-reconnected.json>)、[证据4](<C:\Users\Billy\Desktop\Denzic\Companion\docs\handoffs\20261106-companion-device-management\phone065-final-idle-uart.json>)

### 已验能力，直接复用

| 能力 | 验证范围与限制 |
|---|---|
| 实体按键离线开录、停止及保存 | 旧66665离线207.43秒证据保留；FW66675 Owner分步实键长按开录、录中短按标记、长按停录，d7原音48.91秒及一标记精确收取解码，未用UART/BLE开停录。实际成功停录边沿1250ms；不追改前两次失败，不代表无提示硬件的独立可用性已收尾。 [证据1](E:/CodexData/Companion/capture-closeout-20261105/owner-session-r3/after/result.json)、[证据2](E:/CodexData/Companion/capture-closeout-20261105/received-66675-d7/acceptance.json) |
| 真实采音、分段提交和精确收取 | 复用历史长录及本轮181.12秒完整收取；不重复无变化长录。 [证据1](E:/CodexData/Companion/recording-recovery-20261104/sync-pause-live-r1/result.json) |
| 同会话断点续收 | 会话205从已落盘65536字节续收，只读取本次两段。 [证据1](E:/CodexData/Companion/recording-recovery-20261104/receive205/resume-result.json) |
| 暂停同步、录中接收端退出后原会话恢复 | 206/207暂停同步和接收端退出已验；208实板系统蓝牙关闭后同key继续录182.8秒并完整保存。软件断链合并验收，不扩大为RF覆盖资格。 [证据1](E:/CodexData/Companion/recording-recovery-20261104/sync-pause-live-r1/result.json)、[证据2](E:/CodexData/Companion/recording-recovery-20261104/receiver-exit-live-r1/result.json)、[证据3](E:/CodexData/Companion/capture-core-closeout-20261104/radio-loss-r2/acceptance.json) |
| 中间连续空闲区的完整签名蓝牙OTA | 同UI85静态边界、完整固件与资源包、原Boot安装并释放临时空间；不含安装中物理断电或生产密钥。 [证据1](E:/CodexData/Companion/firmware-builds/fw66667-normal-ota-r2/result.json)、[证据2](E:\CodexData\Companion\capture-closeout-20261105\ota66676\ota-result.json)、[证据3](E:/CodexData/Companion/capture-closeout-20261105/ota66677/ota-result.json) |
| 可关闭的外部Flash持久诊断 | F000独立4KiB，已读回跨复位记录；真实HardFault注入未资格。 [证据1](E:/CodexData/Companion/recording-recovery-20261104/uart-final-idle.log) |
| 真实满空间封口、完整收取、回收后再录及响应 | 真实自然35m11.07s满盘、封口与17段原音完整收取已验；满盘START拒绝15/31ms。FW66692取消未使用预留的重复扫描/无关擦除，66693修低功耗入口漏报存储前台工作；三次正常START1.891/1.109/1.125s、STOP188/171/172ms均达原2s/500ms。每场原音CRC/SHA/连续时间轴/WAV及精确回收通过，原34段不变、4608000B/17段恢复。 关闭实际空间耗尽/回收后普通再录与本批响应缺陷。物理介质故障/录中掉电、两小时并发、首字听感及整机电源资格不在此关闭范围；旧模型关闭、真实失败和原指标均保留。 [证据1](C:\Users\Billy\Desktop\Denzic\Companion\docs\handoffs\20261106-companion-device-management\full-media66690\full-stop.json)、[证据2](C:\Users\Billy\Desktop\Denzic\Companion\docs\handoffs\20261106-companion-device-management\full-media66690\full-receiver-windows067.json)、[证据3](C:\Users\Billy\Desktop\Denzic\Companion\docs\handoffs\20261106-companion-device-management\full-media66691\actual-full-and-restart.json)、[证据4](C:\Users\Billy\Desktop\Denzic\Companion\docs\handoffs\20261106-companion-device-management\full-media66693\control-latency.json)、[证据5](C:\Users\Billy\Desktop\Denzic\Companion\docs\handoffs\20261106-companion-device-management\full-media66693\final-idle.json) |
| Capture无屏自动Stop1与唤醒后录音 | FW66677修复连续短眠计时偏差，实际120秒对照在完整测量窗口内，6513次短眠/恢复失败0；醒后9.08秒原音/两标记完整收取。实键沿FW66675 d7；不含真实耗电、长期精度或新板资格。 [证据1](E:\CodexData\Companion\power-closeout-20261104\fw66671-hardware\acceptance.json)、[证据2](E:\CodexData\Companion\capture-closeout-20261105\adc-paused-acceptance.json)、[证据3](E:/CodexData/Companion/capture-closeout-20261105/clock-fix-acceptance.json) |
| 本地短按连接、Windows/Android重连及忘记设备后重配 | Windows忘记后重配/加密读取/重收已验。FW66675空闲短按185ms开窗并正常到期；Android6次板端secured1，含测试程序退出后闭窗重连、手机无配对记录后重配及再次连接，外部绑定写1完成；手机重配后Windows仍可加密访问。首轮直连19原因未定保留，不含生产App首引导/出厂空绑定/新板LED。 [证据1](E:/CodexData/Companion/capture-closeout-20261105/windows-forget-rebind-recovery/acceptance.json)、[证据2](E:/CodexData/Companion/capture-closeout-20261105/after-rebind-receive/acceptance.json)、[证据3](E:/CodexData/Companion/capture-closeout-20261105/pair-button-phone/button-acceptance.json)、[证据4](E:/CodexData/Companion/capture-closeout-20261105/android-metadata/acceptance.json) |
| Companion设备指定场次删除与空间回收 | 实际Cancel保留e5；普通删除完成回收；只收e5原音2040ms/32640样本并耐久校验后精确消费；暂停自动同步选择保持。最终34原目录逐条一致、空闲空间4608000B、UART正常空闲且linked0；全部句柄已关闭、板卡已release。 仅固件及隔离Windows候选，手机普通入口和日用发布未关闭。 [证据1](C:\Users\Billy\Desktop\Denzic\Companion\docs\handoffs\20261106-companion-device-management\acceptance.json) |
| Companion普通Windows按场收取 | 实际Cancel保留e5；普通删除完成回收；只收e5原音2040ms/32640样本并耐久校验后精确消费；暂停自动同步选择保持。最终34原目录逐条一致、空闲空间4608000B、UART正常空闲且linked0；全部句柄已关闭、板卡已release。 仅固件及隔离Windows候选，手机普通入口和日用发布未关闭。 [证据1](C:\Users\Billy\Desktop\Denzic\Companion\docs\handoffs\20261106-companion-device-management\acceptance.json) |

### 明确后置，不自动恢复

- **Capture硬件适配、生产升级与出厂资格：** 开发签名路径不等于量产信任链；真实断电、生产密钥和出厂测试按原阶段后置。 Capture新板无屏控制/配对/反馈和RF覆盖须按实际硬件适配，当前Companion录音内核收尾不替代这些交付资格。 原编号：[CP23-03](PRODUCT_BACKLOG_HISTORY.md#cp23-03)、[CP23-07](PRODUCT_BACKLOG_HISTORY.md#cp23-07)、[CP23-09](PRODUCT_BACKLOG_HISTORY.md#cp23-09)、[CP21-06](PRODUCT_BACKLOG_HISTORY.md#cp21-06)、[CP27-12](PRODUCT_BACKLOG_HISTORY.md#cp27-12)、[CP24-07](PRODUCT_BACKLOG_HISTORY.md#cp24-07)
- **设备离线管理及其他录音增强：** 无屏版无需设备屏幕列表；语音/预约/预录保留后续增强。离线实体标记已在FW66675实键及66677原音收取验证，不再混在“未做增强”里；标记反馈时机沿当前CP04-01补齐。 原编号：[CP27-20](PRODUCT_BACKLOG_HISTORY.md#cp27-20)、[CP27-17](PRODUCT_BACKLOG_HISTORY.md#cp27-17)、[CP27-21](PRODUCT_BACKLOG_HISTORY.md#cp27-21)、[CP27-22](PRODUCT_BACKLOG_HISTORY.md#cp27-22)、[CP27-23](PRODUCT_BACKLOG_HISTORY.md#cp27-23)
- **屏幕、触摸与宠物交互（Owner暂停）：** Owner 2026-11-04明确下一款Capture只有录音卡、没有屏幕，屏幕/触摸/宠物交互先暂停，其余工作完成后再回来。 原编号：[CP04-03](PRODUCT_BACKLOG_HISTORY.md#cp04-03)、[CP21-02](PRODUCT_BACKLOG_HISTORY.md#cp21-02)、[CP24-05](PRODUCT_BACKLOG_HISTORY.md#cp24-05)

### 不重复做

- 已通过的普通短录、暂停同步、进程退出恢复、同边界普通OTA和持久日志不重新开发。
- 测速、新模型和逐函数优化不因旧工作点自动恢复。
- 不将串口录中静默或有手动插拔条件的重启记录判作自动死机。
- 屏幕、触摸、宠物与显示菜单不作为当前录音卡验收前置；保留故障和原代码，完成其他工作后再回来。

### 入口与历史

- 当前工作点：`python tools/render_product_backlog.py --workpoint --focus recorder --compact`。
- 更新可读视图：`python tools/render_product_backlog.py --docs-only`；不会写产品参数或操作设备。
- [原CP编号与历史证据](PRODUCT_BACKLOG_HISTORY.md)仅供定位与防回退。
- [唯一开发时间线](development_log.md)。
