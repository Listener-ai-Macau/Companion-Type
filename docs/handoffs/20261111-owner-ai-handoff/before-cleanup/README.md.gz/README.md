# Companion：当前项目入口

嵌软先看[当前待办](docs/RECORDER_CORE_BACKLOG.md)：当前工作、已验证范围和明确后置事项都在这里。任务数量按可交付工作包统计，原272个工程编号供追溯，不能当成272个当前未完成项目。

| 要看什么 | 入口 |
|---|---|
| 本侧当前工作与已装固件证据 | [嵌入式当前待办](docs/RECORDER_CORE_BACKLOG.md) |
| 六模块、电脑/手机当前交付与分工 | [当前产品交付](docs/PRODUCT_BACKLOG.md) |
| 原CP编号、旧状态与原证据 | [历史索引](docs/PRODUCT_BACKLOG_HISTORY.md) |
| 屏幕与互动工作 | [屏幕与互动待办](docs/SCREEN_INTERACTION_BACKLOG.md) |
| 完整修改、失败与剩余 | [唯一开发时间线](docs/development_log.md) |
| 当前源码、候选和版本证据 | [版本索引](docs/ITERATION_HISTORY.md) |
| 接板前实际占用 | [实板操作记录](docs/board_operations.md) |

后台读取当前工作点：

```powershell
python tools/render_product_backlog.py
python tools/build_current_firmware.py --show
```

前者默认只读；`--docs-only` 仅根据[唯一待办数据](docs/product_backlog.json)更新可读文档，不再改Type产品参数。后者只显示当前源码、配方参考及已保存安装证据；实际构建时指定新版本。

当前固件源码在[firmware-current](E:/CodexData/Companion/firmware-current/)。当前Type前端源码由同事在 `E:/CodexData/Companion/unified-frontends-r2-20261102/source` 维护；桌面历史checkout不能凭名字视作当前交付。规则从[Denzic共用入口](../AGENTS.md)进入，再沿[本项目规则](AGENTS.md)处理。

旧Goal、旧WB55/WBA操作入口和早期版本说明已退出当前入口，原件与SHA保存在[本次整理存档](archive/embedded-entry-cleanup-20261104-192726/manifest.json)；[此前固件入口退役记录](archive/firmware-entry-retirement-20261104/retirement.json)继续保留。原音、已验证产物和失败证据均保留。
